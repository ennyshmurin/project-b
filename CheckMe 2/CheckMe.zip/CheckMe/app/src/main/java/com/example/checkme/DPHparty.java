package com.example.checkme;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DPHparty {

    public static Context Context;

    public static void StoreData(List<Item> items)
    {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
        SharedPreferences.Editor editor = sp.edit();
        String json = new Gson().toJson(items);
        editor.putString("items", json);
        editor.commit();
    }

    public static List<Item> LoadData()
    {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
        String json = sp.getString("items",null);
        if (json != null)
        {
            Type type = new TypeToken<List<Item>>(){}.getType();
            return new Gson().fromJson(json,type);
        }
        else
        {
            List<Item> items = new ArrayList<Item>();
            items.add(new Item("Vodka"));
            items.add(new Item("Rum"));
            items.add(new Item("Tequila"));
            return items;
        }
    }

}

