package com.example.checkme;


import java.io.Serializable;

public class CheckList implements Serializable {

    private int Image;
    private String name;


    public int getImage() {
        return Image;
    }

    public String getName() {
        return name;
    }


    public CheckList(int image, String name)
    {
        this.Image = image;
        this.name = name;
    }

}