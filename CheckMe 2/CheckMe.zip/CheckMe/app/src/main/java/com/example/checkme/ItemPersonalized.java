package com.example.checkme;

import java.io.Serializable;



public class ItemPersonalized implements Serializable {

        private static String title;
        public Boolean done = false;

        public ItemPersonalized(String title) {
            this.title = title;

        }

        public static String getItem() {
            return title;
        }


        public Boolean isDone() {
            return done;
        }

        }


