package com.example.checkme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    private RecyclerView itemsRecyclerView;
    private ItemAdapter itemsAdapter;

    private List<Item> items;
    private Object ItemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        DataPersistencyHelper.Context = getApplicationContext();
        List<CheckList> items = DataPersistencyHelper.LoadData();

        RecyclerView recycler = findViewById(R.id.recycler2);
        recycler.setHasFixedSize(false);

        RecyclerView.LayoutManager manager = new GridLayoutManager(getApplicationContext(), 1);
        recycler.setLayoutManager(manager);


        ItemAdapter = new ItemAdapter(this);
        itemsRecyclerView.setAdapter((RecyclerView.Adapter) ItemAdapter);

    }
}
