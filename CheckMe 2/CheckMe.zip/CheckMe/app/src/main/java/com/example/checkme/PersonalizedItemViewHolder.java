package com.example.checkme;

import android.view.View;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


public class PersonalizedItemViewHolder extends RecyclerView.ViewHolder {

        public CardView card;
        public CheckBox checkbox;

        public PersonalizedItemViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.card);
            checkbox = itemView.findViewById(R.id.card2);

        }
    }

